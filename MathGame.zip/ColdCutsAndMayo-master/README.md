Software Engineering Project Spring 2019. Members: Anna Marno, Dalton Rutledge, and Emily Mason

Using Unity and S3 serverless webapp hosting

Test Code can be found in the Lambda Folder
