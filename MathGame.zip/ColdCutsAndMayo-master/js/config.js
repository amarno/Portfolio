window._config = {
    cognito: {
        userPoolId: 'us-west-2_84wUAH9xK', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '3d68q9ar8sfjtmpsa6kg74q9rv', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv 
        region: 'us-west-2' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://cs95gbqvoi.execute-api.us-west-2.amazonaws.com/getANDpost' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};