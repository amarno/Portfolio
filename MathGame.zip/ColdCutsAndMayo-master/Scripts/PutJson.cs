﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PutJson : MonoBehaviour
{
    public string Time_Played;
    public string Level_Wins;
    public string Level_Losses;
    public List<string> Wrong_Probs;

}
